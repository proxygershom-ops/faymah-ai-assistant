package com.faymah.aiassistant

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private val Navy = Color(0xFF06122E)
private val Navy2 = Color(0xFF0A1C3B)
private val Blue = Color(0xFF087CFF)
private val Cyan = Color(0xFF16D9F5)
private val Green = Color(0xFF32D46A)
private val Gold = Color(0xFFFFC928)
private val TextSoft = Color(0xFFD8E5FF)

private data class ChatMessage(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FaymahApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FaymahApp() {
    val messages = remember { mutableStateListOf(ChatMessage("Hello! I'm Faymah AI. How can I help you today?", false)) }
    val conversations = remember { mutableStateListOf("New conversation") }
    var input by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var drawerOpen by remember { mutableStateOf(false) }
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    var settingsOpen by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val context = androidx.compose.ui.platform.LocalContext.current

    LaunchedEffect(drawerOpen) { if (drawerOpen) drawerState.open() else drawerState.close() }

    MaterialTheme(colorScheme = MaterialTheme.colorScheme.copy(primary = Blue, secondary = Cyan)) {
        ModalNavigationDrawer(
            drawerState = drawerState,
            drawerContent = {
                ModalDrawerSheet(drawerContainerColor = Navy2) {
                    Spacer(Modifier.height(28.dp))
                    Image(painterResource(R.drawable.faymah_logo), "Faymah logo", Modifier.size(90.dp).align(Alignment.CenterHorizontally))
                    Text("FAYMAH", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black, modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 8.dp))
                    Text("AI ASSISTANT", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.CenterHorizontally))
                    Spacer(Modifier.height(24.dp))
                    NavigationDrawerItem(label = { Text("New chat") }, selected = false, onClick = { messages.clear(); messages.add(ChatMessage("Hello! I'm Faymah AI. How can I help you today?", false)); drawerOpen = false }, icon = { Icon(Icons.Default.AddComment, null) }, colors = drawerColors())
                    NavigationDrawerItem(label = { Text("History") }, selected = false, onClick = { drawerOpen = false }, icon = { Icon(Icons.Default.History, null) }, colors = drawerColors())
                    NavigationDrawerItem(label = { Text("Settings") }, selected = false, onClick = { drawerOpen = false; settingsOpen = true }, icon = { Icon(Icons.Default.Settings, null) }, colors = drawerColors())
                    Spacer(Modifier.weight(1f))
                    Text("Your Questions • Our AI • Real Solutions", color = TextSoft, fontSize = 12.sp, modifier = Modifier.padding(18.dp))
                }
            }
        ) {
            Scaffold(
                topBar = {
                    TopAppBar(
                        navigationIcon = { IconButton(onClick = { drawerOpen = true }) { Icon(Icons.Default.Menu, "Menu", tint = Color.White) } },
                        title = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Image(painterResource(R.drawable.faymah_logo), "Faymah logo", Modifier.size(42.dp).clip(CircleShape), contentScale = ContentScale.Crop)
                                Spacer(Modifier.width(9.dp))
                                Column { Text("FAYMAH", color = Color.White, fontWeight = FontWeight.Black); Text("AI ASSISTANT", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                            }
                        },
                        actions = { IconButton(onClick = { settingsOpen = true }) { Icon(Icons.Default.Settings, "Settings", tint = Color.White) } },
                        colors = TopAppBarDefaults.topAppBarColors(containerColor = Navy)
                    )
                },
                bottomBar = {
                    Composer(input, { input = it }, !loading) {
                        val q = input.trim()
                        if (q.isNotEmpty() && !loading) {
                            messages.add(ChatMessage(q, true)); input = ""; loading = true
                            scope.launch {
                                val answer = withContext(Dispatchers.IO) { askFaymah(q) }
                                messages.add(ChatMessage(answer, false)); loading = false
                                listState.animateScrollToItem(messages.lastIndex)
                            }
                        }
                    }
                },
                containerColor = Navy
            ) { padding ->
                LazyColumn(state = listState, modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(vertical = 16.dp)) {
                    item { WelcomeCard(onSuggestion = { input = it }) }
                    itemsIndexed(messages) { index, message -> MessageBubble(message, onCopy = { copyToClipboard(context, message.text) }, onShare = { shareText(context, message.text) }) }
                    if (loading) item { TypingBubble() }
                }
            }
        }
    }

    if (settingsOpen) SettingsDialog(onDismiss = { settingsOpen = false })
}


@Composable
private fun drawerColors() = NavigationDrawerItemDefaults.colors(unselectedContainerColor = Color.Transparent, unselectedTextColor = Color.White, unselectedIconColor = TextSoft)

@Composable
private fun WelcomeCard(onSuggestion: (String) -> Unit) {
    Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Navy2), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Blue, Cyan, Green)))) { Icon(Icons.Default.SmartToy, null, tint = Color.White, modifier = Modifier.align(Alignment.Center)) }
                Spacer(Modifier.width(11.dp)); Text("Your Questions • Our AI • Real Solutions", color = Color.White, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(9.dp)); Text("Ask questions, learn, write, calculate, translate and solve everyday problems with Faymah AI.", color = TextSoft, lineHeight = 20.sp)
            Spacer(Modifier.height(14.dp)); Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Suggestion("Ask anything") { onSuggestion("Explain something to me") }
                Suggestion("Study") { onSuggestion("Help me study") }
                Suggestion("Solve") { onSuggestion("Help me solve a problem") }
            }
        }
    }
}

@Composable private fun Suggestion(text: String, onClick: () -> Unit) { AssistChip(onClick = onClick, label = { Text(text, fontSize = 11.sp) }, colors = AssistChipDefaults.assistChipColors(containerColor = Color(0xFF103B75), labelColor = Color.White)) }

@Composable
private fun MessageBubble(message: ChatMessage, onCopy: () -> Unit, onShare: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start) {
        Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = if (message.fromUser) Blue else Color(0xFF11274B)), modifier = Modifier.fillMaxWidth(0.90f)) {
            Column(Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (message.fromUser) Icons.Default.Person else Icons.Default.SmartToy, null, tint = if (message.fromUser) Color.White else Cyan, modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(7.dp)); Text(if (message.fromUser) "You" else "Faymah AI", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
                Spacer(Modifier.height(7.dp)); Text(message.text, color = Color.White, lineHeight = 21.sp)
                if (!message.fromUser) {
                    Spacer(Modifier.height(5.dp)); Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        IconButton(onClick = onCopy, modifier = Modifier.size(32.dp)) { Icon(Icons.Default.ContentCopy, "Copy", tint = TextSoft, modifier = Modifier.size(16.dp)) }
                        IconButton(onClick = onShare, modifier = Modifier.size(32.dp)) { Icon(Icons.Default.Share, "Share", tint = TextSoft, modifier = Modifier.size(16.dp)) }
                    }
                }
            }
        }
    }
}

@Composable private fun TypingBubble() { Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF11274B)), shape = RoundedCornerShape(18.dp)) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = Cyan); Spacer(Modifier.width(9.dp)); Text("Faymah is thinking...", color = TextSoft) } } }

@Composable
private fun Composer(value: String, onValueChange: (String) -> Unit, enabled: Boolean, onSend: () -> Unit) {
    Surface(color = Navy, modifier = Modifier.navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value, onValueChange, enabled = enabled, modifier = Modifier.weight(1f), placeholder = { Text("Ask Faymah anything...", color = Color(0xFF7892B8)) }, maxLines = 4, shape = RoundedCornerShape(22.dp), colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = Cyan, unfocusedBorderColor = Color(0xFF27466F), cursorColor = Cyan))
            Spacer(Modifier.width(8.dp)); Button(onClick = onSend, enabled = enabled && value.isNotBlank(), modifier = Modifier.size(54.dp), shape = RoundedCornerShape(18.dp), contentPadding = PaddingValues(0.dp), colors = ButtonDefaults.buttonColors(containerColor = Blue)) { Icon(Icons.Default.Send, "Send", tint = Color.White) }
        }
    }
}

@Composable
private fun SettingsDialog(onDismiss: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } }, title = { Text("Faymah Settings") }, text = { Column(verticalArrangement = Arrangement.spacedBy(12.dp)) { Text("FAYMAH AI ASSISTANT", fontWeight = FontWeight.Bold); Text("Your Questions • Our AI • Real Solutions"); Text("Version 1.0"); Text("AI responses require an active internet connection and configured Faymah backend.") } })
}

private fun copyToClipboard(context: Context, text: String) { val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager; clipboard.setPrimaryClip(ClipData.newPlainText("Faymah AI", text)) }
private fun shareText(context: Context, text: String) { context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }, "Share Faymah answer")) }

private fun askFaymah(question: String): String {
    val endpoint = BuildConfig.FAYMAH_API_URL
    if (endpoint.isBlank()) return "Demo mode is active. Connect the Faymah backend to enable live AI answers.\n\nYour question was:\n$question"
    return try {
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply { requestMethod = "POST"; connectTimeout = 15000; readTimeout = 60000; doOutput = true; setRequestProperty("Content-Type", "application/json") }
        connection.outputStream.use { it.write(JSONObject().put("message", question).toString().toByteArray()) }
        val responseCode = connection.responseCode
        val stream = if (responseCode in 200..299) connection.inputStream else connection.errorStream
        val response = stream.bufferedReader().use { it.readText() }
        if (responseCode !in 200..299) return "Faymah could not answer right now. Please try again."
        JSONObject(response).optString("answer", "No answer was returned.")
    } catch (_: Exception) { "Faymah is temporarily offline. Check your internet connection or backend server." }
}
