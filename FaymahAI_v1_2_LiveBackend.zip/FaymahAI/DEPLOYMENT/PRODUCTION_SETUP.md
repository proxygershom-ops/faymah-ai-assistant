# FAYMAH Production Setup

## Backend environment
Required:
- OPENAI_API_KEY
- OPENAI_MODEL (default: gpt-5.6-luna)
- PORT (default: 8080)
- ALLOWED_ORIGIN
- RATE_LIMIT_PER_MINUTE
- MAX_MESSAGE_CHARS

## Endpoint
POST /api/chat
JSON body:
{"message":"Hello Faymah"}

Response:
{"answer":"..."}

Health:
GET /health

## Android
Build with the deployed HTTPS endpoint:
FAYMAH_API_URL=https://YOUR-DOMAIN/api/chat

Do not use an HTTP endpoint in production.
