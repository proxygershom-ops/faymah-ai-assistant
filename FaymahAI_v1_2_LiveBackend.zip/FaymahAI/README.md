# FAYMAH AI ASSISTANT

FAYMAH is a branded AI assistant for questions, learning, writing, calculations, translation and everyday problem solving.

## Current build
- Kotlin + Jetpack Compose Android app
- Circular FAYMAH branding using navy, blue, cyan, green, gold and white
- AI chat interface, quick prompts, loading state, copy/share
- New chat, History and Settings structure
- Backend connection through HTTPS
- Server-side OpenAI Responses API integration
- Basic API rate limiting and input validation
- Android target SDK 36

## Configure the Android app
The API URL is supplied as a Gradle property so the source does not need to be edited.
Example:

`./gradlew assembleDebug -PFAYMAH_API_URL=https://YOUR-DOMAIN.example/api/chat`

For Android Studio, add `FAYMAH_API_URL=https://YOUR-DOMAIN.example/api/chat` to the Gradle command-line options or project Gradle properties used for your local build.

## Backend
1. Install Node.js 20+.
2. `cd backend`
3. `npm install`
4. Copy `.env.example` to `.env`.
5. Add the server-side `OPENAI_API_KEY`.
6. `npm start`
7. Deploy behind HTTPS.

The API key must never be stored in the Android application.

## Production work remaining
- Authentication and account management
- Persistent cloud chat history
- Billing/usage limits if monetized
- Voice and image features
- Monitoring and abuse controls
- Privacy policy/terms finalization
- Signed AAB and Play Console testing/publication
