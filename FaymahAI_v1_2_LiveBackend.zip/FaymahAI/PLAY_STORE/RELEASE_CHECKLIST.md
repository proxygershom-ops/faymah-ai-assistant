# FAYMAH AI ASSISTANT - Play Store release checklist

## App identity
- App name: FAYMAH AI ASSISTANT
- Short description: Ask questions, solve problems and get useful AI answers with Faymah.
- Category: Productivity / Education (choose the most accurate category at submission time).
- Primary promise: Your Questions • Our AI • Real Solutions

## Store assets to prepare
- 512 x 512 Play Store app icon
- Phone screenshots showing Home, Chat, History and Settings
- Feature graphic
- Privacy policy URL
- Support/contact email

## Technical release
- Set a unique production application ID if required.
- Configure production HTTPS backend URL.
- Configure server-side AI key and usage limits.
- Test sign-in and chat flows.
- Test offline/error states.
- Test on multiple Android screen sizes.
- Generate a signed Android App Bundle (.aab).
- Complete Play Console verification and required testing.
- Complete Data Safety and app-content declarations.
