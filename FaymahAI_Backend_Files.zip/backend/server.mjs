import express from "express";
import dotenv from "dotenv";
import OpenAI from "openai";

// FAYMAH AI ASSISTANT production API
// The OpenAI API key stays on this server and is never shipped in the Android app.
dotenv.config();

const app = express();
const port = Number(process.env.PORT || 8080);
const apiKey = process.env.OPENAI_API_KEY;
const model = process.env.OPENAI_MODEL || "gpt-5.6-luna";
const client = apiKey ? new OpenAI({ apiKey }) : null;
const allowedOrigin = process.env.ALLOWED_ORIGIN || "*";
const maxMessageChars = Number(process.env.MAX_MESSAGE_CHARS || 12000);
const rateWindowMs = 60_000;
const rateLimit = Number(process.env.RATE_LIMIT_PER_MINUTE || 30);
const buckets = new Map();

app.disable("x-powered-by");
app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", allowedOrigin);
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  if (req.method === "OPTIONS") return res.sendStatus(204);
  next();
});
app.use(express.json({ limit: "1mb" }));

function clientKey(req) {
  const forwarded = req.headers["x-forwarded-for"];
  return String(forwarded || req.ip || "unknown").split(",")[0].trim();
}

function limited(req) {
  const now = Date.now();
  const key = clientKey(req);
  const current = buckets.get(key) || { start: now, count: 0 };
  if (now - current.start >= rateWindowMs) {
    current.start = now;
    current.count = 0;
  }
  current.count += 1;
  buckets.set(key, current);
  return current.count > rateLimit;
}

app.get("/health", (_req, res) => {
  res.json({ ok: true, service: "Faymah AI", aiConfigured: Boolean(client), model });
});

app.post("/api/chat", async (req, res) => {
  if (limited(req)) {
    return res.status(429).json({ error: "Too many requests. Please try again shortly." });
  }

  const message = String(req.body?.message || "").trim();
  if (!message) return res.status(400).json({ error: "Message is required" });
  if (message.length > maxMessageChars) {
    return res.status(413).json({ error: `Message is too long. Maximum is ${maxMessageChars} characters.` });
  }
  if (!client) return res.status(503).json({ error: "Faymah AI service is not configured yet." });

  try {
    const response = await client.responses.create({
      model,
      instructions: `You are FAYMAH AI ASSISTANT, a helpful AI assistant for people in Malawi and worldwide.

Your job is to answer questions clearly, accurately and practically. Use simple language when appropriate. Show full working for mathematics and engineering calculations. Help with education, writing, translation, general knowledge, planning and everyday problems. Do not pretend to know facts you are uncertain about. For medical, legal, financial and safety topics, give general information and recommend a qualified professional when appropriate. Never claim to have taken an action that you did not take.`,
      input: message,
      store: false
    });

    res.json({ answer: response.output_text || "I could not produce an answer." });
  } catch (error) {
    console.error("Faymah AI error:", error?.message || error);
    res.status(502).json({ error: "Faymah AI is temporarily unavailable. Please try again." });
  }
});

app.listen(port, () => console.log(`Faymah backend listening on port ${port}`));
